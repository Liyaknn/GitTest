grams = int(input("Write grams : "))
def converting(grams):
    print("Result is : ", 28.3495231 * grams)

converting(grams)
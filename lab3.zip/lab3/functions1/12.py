def histogram(inputList):
    for i in inputList:
        print("*" * i)

myList = [1,2,3,4,5]
histogram(myList)
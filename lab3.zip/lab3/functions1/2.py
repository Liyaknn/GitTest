F = int(input("Fahrenheit temperature : "))
def myfunc(F):
    print("The equivalent centigrade temperature is : ", int((5 / 9) * (F - 32)))

myfunc(F)
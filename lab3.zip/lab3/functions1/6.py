def toReverse(s):
    reversed_s = " ".join(reversed(s.split()))
    print(reversed_s)
s = str(input())
toReverse(s)